package com.liza.message.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MessagesServiceController {
    private final Set<String> set = new HashSet<>();
    public final static String MY_QUEUE = "my_queue";
    private static final ConnectionFactory factory = new ConnectionFactory();

    @PostConstruct
    private void constructor() {
        try {
            init();
            DeliverCallback deliverCallback = (consumerTag, delivery) -> {
                String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
                set.add(message);
                System.out.println(" [x] Received '" + message + "'");
                channel.basicAck(delivery.getEnvelope().getDeliveryTag(), true);
            };
            channel.basicConsume(QUEUE, false, deliverCallback, consumerTag -> { });
        } catch (IOException | TimeoutException ignored) {
        }
    }

    private void init() {
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();
        channel.basicQos(1);
    }

    @GetMapping("/messages")
    @ResponseBody
    public String message(){
        String str = null;
        for (String s : set) {
            str += s + "\n";
        }
        return str;
    }
}
