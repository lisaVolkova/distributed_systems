package com.liza.lab2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacadeApp {

    public static void main(String[] args) {
        SpringApplication.run(FacadeApp.class, args);
    }

}
